int initnotify(int signo1, int signo2);
int waitnotifyon(void);
