int initqueue(int key);
int msgprintf(char *fmt, ...);
int msgread(void *buf, int len);
int msgwrite(void *buf, int lne);
int removequeue(void);
