#define BUFSIZE 8
typedef double buffer_t;
int getitem(buffer_t *itemp);
int putitem(buffer_t item); 
