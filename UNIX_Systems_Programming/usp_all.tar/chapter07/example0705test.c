#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(void) {

#include "example0705.c"

{
#include "exercise0702.c"
}

   return 0;
}
