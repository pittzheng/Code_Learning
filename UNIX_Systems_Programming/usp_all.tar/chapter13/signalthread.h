int signalthreadinit(int signo);
