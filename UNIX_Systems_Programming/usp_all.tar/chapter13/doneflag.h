int getdone(int *flag);
int setdone(void);
