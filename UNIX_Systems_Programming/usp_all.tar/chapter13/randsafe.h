int randsafe(double *ranp);
