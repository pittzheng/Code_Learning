int add(double x);
int getcountandsum(int *countp, double *sump);
int getsum(double *thesum);
