int myarray[50000];

int main(void) {
    myarray[0] = 3;
    return 0;
}
