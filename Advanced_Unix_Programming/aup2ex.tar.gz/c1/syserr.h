#ifndef _SYSERR_
#define _SYSERR_

void syserr(char *msg);

#endif /* _SYSERR_ */
