#ifndef _SETBLOCK_H_
#define _SETBLOCK_H_

bool setblock(int fd, bool on);

#endif /* _SETBLOCK_H_ */
