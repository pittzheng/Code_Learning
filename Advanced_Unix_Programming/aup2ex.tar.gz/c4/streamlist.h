#ifndef _STREAM_LIST_H_
#define _STREAM_LIST_H_

bool stream_list(int fd);

#endif /* _STREAM_LIST_H_ */
