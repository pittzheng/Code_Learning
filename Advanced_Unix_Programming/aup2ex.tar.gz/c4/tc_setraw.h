#ifndef _TC_SETRAW_H_
#define _TC_SETRAW_H_

bool tc_setraw(void);
bool tc_restore(void);
int tc_keystroke(void);

#endif /* _TC_SETRAW_H_ */
