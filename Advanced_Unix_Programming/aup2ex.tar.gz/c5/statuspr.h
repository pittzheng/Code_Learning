#ifndef _STATUSPRT_H_
#define _STATUSPRT_H_

void display_status(pid_t pid, int status);

#endif /* _STATUSPRT_H_ */
