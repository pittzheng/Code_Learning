#ifndef _BUILTIN_H_
#define _BUILTIN_H_

void asg(int argc, char *argv[]);
void set(int argc, char *argv[]);

#endif /* _BUILTIN_H_ */
